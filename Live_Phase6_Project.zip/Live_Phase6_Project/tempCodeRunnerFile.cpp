#include<iostream>
using std::cout;
using std::endl;

int main()
{
    cout << "Namaste duniya" << endl;
}